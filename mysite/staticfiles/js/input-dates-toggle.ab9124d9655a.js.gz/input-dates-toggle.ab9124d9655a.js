var inputStatements = document.querySelector(".input-statements");
var inputDates = document.querySelector(".input-dates");

inputDates.addEventListener("click", function() {
  inputDates.toggleAttribute("disabled");
});
